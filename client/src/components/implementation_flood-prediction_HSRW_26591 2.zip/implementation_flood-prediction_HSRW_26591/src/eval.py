import argparse, pandas as pd
from sklearn.metrics import roc_auc_score, average_precision_score, f1_score

ap = argparse.ArgumentParser()
ap.add_argument("--y_true", required=True, help="CSV with true labels")
ap.add_argument("--y_pred", required=True, help="CSV with predictions (column: y_pred)")
ap.add_argument("--label-col", default="y_true", help="Name of label column in y_true CSV (default: y_true)")
args = ap.parse_args()

df_true = pd.read_csv(args.y_true)
if args.label_col not in df_true.columns:
    raise SystemExit(f"Label column '{args.label_col}' not found in {args.y_true}. Columns: {list(df_true.columns)}")
y_true = df_true[args.label_col].values

df_pred = pd.read_csv(args.y_pred)
col_pred = "y_pred" if "y_pred" in df_pred.columns else df_pred.columns[-1]
y_pred = df_pred[col_pred].values

auc = roc_auc_score(y_true, y_pred)
ap_score = average_precision_score(y_true, y_pred)
f1 = f1_score(y_true, (y_pred >= 0.5).astype(int))

print(f"AUC: {auc:.4f}")
print(f"AP : {ap_score:.4f}")
print(f"F1 : {f1:.4f}")

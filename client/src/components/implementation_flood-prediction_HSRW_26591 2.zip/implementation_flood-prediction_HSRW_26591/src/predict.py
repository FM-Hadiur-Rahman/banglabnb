import argparse, os, sys, warnings
import pandas as pd, numpy as np, joblib

def load_model(path, is_lstm=False):
    if is_lstm or path.endswith(".h5"):
        try:
            import tensorflow as tf
        except Exception as e:
            sys.exit("TensorFlow required for LSTM models. " + str(e))
        return tf.keras.models.load_model(path), "keras"
    return joblib.load(path), "sklearn"

def enforce_feature_order(df, model):
   
    names = getattr(model, "feature_names_in_", None)
    if names is None:
        return df
    names = list(names)
    missing = [c for c in names if c not in df.columns]
    if missing:
     
        for c in missing:
            df[c] = 0.0
        warnings.warn(f"Added missing features with zeros: {missing}")
  
    return df[names]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, help="Path to .pkl or .h5")
    ap.add_argument("--input", required=True, help="CSV with features")
    ap.add_argument("--output", required=True, help="CSV to write predictions")
    ap.add_argument("--lstm", action="store_true", help="Use Keras .h5 model")
    ap.add_argument("--proba_col", default="y_pred", help="Output column name")
    ap.add_argument("--drop-cols", default="", help="Comma-separated columns to drop (e.g. date,id)")
    args = ap.parse_args()

    df_raw = pd.read_csv(args.input)


    if args.drop_cols:
        to_drop = [c for c in [x.strip() for x in args.drop_cols.split(",")] if c]
        df_raw = df_raw.drop(columns=[c for c in to_drop if c in df_raw.columns], errors="ignore")

 
    non_numeric = [c for c in df_raw.columns if not pd.api.types.is_bool_dtype(df_raw[c]) and not pd.api.types.is_numeric_dtype(df_raw[c])]
    if non_numeric:
        warnings.warn(f"Dropping non-numeric columns: {non_numeric}")
        df = df_raw.drop(columns=non_numeric)
    else:
        df = df_raw

    model, kind = load_model(args.model, args.lstm)
    df = enforce_feature_order(df, model)

    if kind == "sklearn":
        if hasattr(model, "predict_proba"):
            y = model.predict_proba(df)[:, -1]
        else:
            y = model.predict(df)
    else:  # keras
        y = model.predict(df.values).squeeze()
        if y.ndim > 1:
            y = y[:, -1]

    os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
    pd.DataFrame({args.proba_col: y}).to_csv(args.output, index=False)
    print(f"Saved predictions -> {args.output}")

if __name__ == "__main__":
    main()

# Links to full datasets (Pegelonline/DWD/GRDC) and licenses.

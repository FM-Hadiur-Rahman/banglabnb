

## Model Cards (summary)
- **xgb_flood_model.pkl** — XGBoost with class weights; expects *lagged* feature set (see `utils.py` / notebooks).
- **xgb_flood_model_no_weight.pkl** — XGBoost **without** class weights (ablation).
- **random_forest_flood_model.pkl** — Random Forest on lagged features.
- **rf_prelag_model.pkl** — Random Forest on **pre-lag** feature schema (different columns/order).
- **logistic_regression_flood_model.pkl** — Logistic baseline.
- **gb_flood_model.pkl** — Gradient Boosting.
- **lstm_flood_model.h5** + **lstm_meta.joblib** — sequence model; `lstm_meta.joblib` contains scaler + window/feature order.

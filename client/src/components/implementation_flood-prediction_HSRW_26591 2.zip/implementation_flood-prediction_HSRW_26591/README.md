# Flood Prediction – Implementation Package (HSRW, Mat.-Nr. 26591)
How to run:
python -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt
python src/predict.py --model models/xgb_flood_model.pkl --input data/sample/flood_model_lagged.csv --output results/preds_xgb.csv
python src/eval.py --y_true data/sample/flood_model_labeled.csv --y_pred results/preds_xgb.csv
See notebooks/ for training and models/ for trained artifacts.

---

## Model Cards (summary)
- **xgb_flood_model.pkl** — XGBoost with class weights; expects *lagged* feature set (see `utils.py` / notebooks).
- **xgb_flood_model_no_weight.pkl** — XGBoost **without** class weights (ablation).
- **random_forest_flood_model.pkl** — Random Forest on lagged features.
- **rf_prelag_model.pkl** — Random Forest on **pre-lag** feature schema (different columns/order).
- **logistic_regression_flood_model.pkl** — Logistic baseline.
- **gb_flood_model.pkl** — Gradient Boosting.
- **lstm_flood_model.h5** + **lstm_meta.joblib** — sequence model; `lstm_meta.joblib` contains scaler + window/feature order.


## Results Included as table, roc curve. 
- `results/roc_curves_all_models.png` — combined ROC figure used in the thesis.
- `results/table_3_2_event_validation.*` — event-level validation tables (CSV/MD/TEX).
- `results/table_3_2_simple_yes_no.csv` — simplified event validation table.

#  Predict (drops non-numeric columns like 'date')
python src/predict.py \
  --model models/xgb_flood_model.pkl \
  --input data/sample/flood_model_lagged.csv \
  --output results/preds_xgb.csv \
  --drop-cols date

#  Evaluate (the  column of sample labelis named as 'flood')
python src/eval.py \
  --y_true data/sample/flood_model_labeled.csv \
  --y_pred results/preds_xgb.csv \
  --label-col flood
## Contents
implementation_flood-prediction_HSRW_26591/
  README.md
  requirements.txt
  notebooks/
    03_model_training.ipynb
    flood_lstm_model.ipynb
    Random_Forest_Flood_Model.ipynb
    XGBoost_flood_Model.ipynb
    Logistic_Regression_Model.ipynb
    ROC_Curves.ipynb
  models/
    xgb_flood_model.pkl
    xgb_flood_model_no_weight.pkl
    random_forest_flood_model.pkl
    rf_prelag_model.pkl
    gb_flood_model.pkl
    logistic_regression_flood_model.pkl
    lstm_flood_model.h5
    lstm_meta.joblib
  data/
    sample/
      flood_model_lagged.csv      
      flood_model_labeled.csv     
    external-links.md             
  src/
    predict.py                    
    eval.py                       
  results/
    roc_curves_all_models.png
    table_3_2_event_validation.csv / .md / .tex
    table_3_2_simple_yes_no.csv
  MODEL_CARDS.md (optional)
## Example (LSTM):
python src/predict.py \
  --model models/lstm_flood_model.h5 \
  --input data/sample/flood_model_lagged.csv \
  --output results/preds_lstm.csv \
  --lstm --drop-cols date

## Data
This package ships with small, non-sensitive samples to illustrate expected schema.
Full datasets are not redistributed due to size and licensing;
## Data Sources (links)
DWD Open Data (CDC): https://opendata.dwd.de/climate_environment/CDC/
DWD root: https://opendata.dwd.de/
Pegelonline: https://www.pegelonline.wsv.de/
Pegelonline REST API: https://www.pegelonline.wsv.de/webservices/rest-api/
GRDC portal: https://portal.grdc.bafg.de/
GRDC info: https://www.bafg.de/GRDC/
